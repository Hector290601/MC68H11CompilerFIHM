/* ------------------------------------------------------------------
 *
 * --- This program is a decimal counter for a 7 segments display.
 * --- It is used to demonstrate the basic features of the THRSim11
 * --- C/C++ support. There is a tutorial page that gives some
 * --- more information using this example. You can find it in the
 * --- help of THRSim11. Just search for "C tutorial"
 *
 * --- You should be reading this commentary with Scite, if not, install
 * --- Scite. See "Scite" in the help of THRSim11 for instructions on how
 * --- to install Scite. 
 *
 * --- SCITE
 *
 * --- Compile the program with Ctrl+F7. This is equivalent to 'make'
 * --- Build the program with F7. This is equivalent to 'make build'
 * --- Compile and start THRSim11 with F5. This is equivalent to 'make'
 * --- and starting THRSim11
 *
 * --- THRSim11
 *
 * --- Connect the 7 segments display via 
 * --- "Connect | 7-Segments Displays | 7-Segments Display"
 * --- Now you can:
 * ---  o Step (F7)
 * ---  o Run (F9), Stop (F2)
 * ---  o View variables in the High Level Language Variables Window
 * ---  o Set breakpoints on source or variables (F5)
 *
 * --- For more information see the "C tutorial" in the help.
 * ------------------------------------------------------------------
 */
 
unsigned char displayTable[10];
volatile unsigned char* displayPort;

void initDisplay() {
	displayTable[0]=0x3f; /* %00111111 */
	displayTable[1]=0x06; /* %00000110 */
	displayTable[2]=0x5b; /* %01011011 */
	displayTable[3]=0x4f; /* %01001111 */
	displayTable[4]=0x66; /* %01100110 */
	displayTable[5]=0x6d; /* %01101101 */
	displayTable[6]=0x7d; /* %01111101 */
	displayTable[7]=0x07; /* %00000111 */
	displayTable[8]=0x7f; /* %01111111 */
	displayTable[9]=0x6f; /* %01101111 */
	displayPort=(unsigned char*)0x1004;
}

void toDisplay(unsigned char c) {
	if(c>=10) {
		*displayPort=0x79; /* %01111001 = E*/
	}
	else {
		*displayPort=displayTable[c];
	}
}

void wait() {
	volatile unsigned short int i;
	for (i=0; i<500; ++i) 
		/*empty*/;
}

int main() {
	unsigned short int count;
	initDisplay();
	while(1) {
		for(count=0; count<10; ++count) {
			toDisplay(count);
			wait();
		}
	}
	return 0;
}
